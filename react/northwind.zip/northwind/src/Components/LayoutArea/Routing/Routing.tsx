import { Navigate, Route, Routes } from "react-router-dom";
import About from "../../AboutArea/About/About";
import Home from "../../HomeArea/Home/Home";
import ProductList from "../../ProductsArea/ProductList/ProductList";
import PageNotFound from "../PageNotFound/PageNotFound";
import "./Routing.css";

function Routing(): JSX.Element {
  return (
    <div className="Routing">
      <Routes>
        {/* HOME */}
        <Route path="/home" element={<Home />} />

        {/* PRODUCTS */}
        <Route path="/products" element={<ProductList />} />

        {/* ABOUT */}
        <Route path="/about" element={<About />} />

        {/* Default Rout */}
        <Route path="/" element={<Navigate to="/home" />} />


        {/* Page not Found */}
        <Route path="*" element={<PageNotFound />} />

      </Routes>
    </div>
  );
}

export default Routing;
