import { SyntheticEvent } from "react";
import "./Recommendation.css";

function Recommendation(): JSX.Element {
  function recommend(e: SyntheticEvent) {
    alert("Irish Coffee");
    console.log(e);
  }
  return (
    <div className="Recommendation Box">
      <button onClick={recommend}>Recommend</button>
    </div>
  );
}

export default Recommendation;
