import { useState } from "react";
import "./BestSeller.css";

function BestSeller(): JSX.Element {
  //let totalItems = 0;

  const nameArray = useState<string>(""); // "" is the initial value
  const name = nameArray[0]; // this is the state property
  const setName = nameArray[1]; // this is a fuction for changing the state

  // same but using destructuring assignment:
  const [totalItems, setTotalItems] = useState<number>(0); // 0 is the initial value

  function display() {
    // demo for getting best seller from backend:
    setName("Exotic Liquids"); // calling the function will (a) change the state, (b) reender this component again
    setTotalItems(17);
  }

  return (
    <div className="BestSeller Box">
      <button onClick={display}>Display Best Seller</button>
      <span>
        Name: {name}, Total Items: {totalItems}
      </span>
    </div>
  );
}

export default BestSeller;
