import { useEffect, useState } from "react";
import "./MoneyBack.css";

function MoneyBack(): JSX.Element {
  const [money, setMoney] = useState<number>(0);
  let obj1, obj2;

  // calling a function only once:
  useEffect(() => {
    setTimeout(() => {
      setMoney(Math.floor(Math.random() * 51) + 5); // Async
    }, 3000);
  }, [obj1, obj2]);

  return (
    <div className="MoneyBack Box">
      <span>Money Back: {money}</span>
    </div>
  );
}

export default MoneyBack;
