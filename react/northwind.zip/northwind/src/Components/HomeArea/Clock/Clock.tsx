import { useEffect, useState } from "react";
import "./Clock.css";

function Clock(): JSX.Element {
  const [time, setTime] = useState<String>(new Date().toLocaleTimeString());

  useEffect(() => {
    const timerId = window.setInterval(() => {
      const now = new Date();
      setTime(now.toLocaleTimeString());
      // console.log(now.toLocaleTimeString());
    }, 1000);

    // following function will be called when our component is about to be destroied:
    return () => {
      clearInterval(timerId);
    };
  }, []);

  return (
    <div className="Clock Box">
      <span>{time}</span>
    </div>
  );
}

export default Clock;
