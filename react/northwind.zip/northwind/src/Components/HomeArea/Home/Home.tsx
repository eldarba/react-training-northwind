import ProductModel from "../../../Models/ProductModel";
import BestSeller from "../BestSeller/BestSeller";
import Clock from "../Clock/Clock";
import Desserts from "../Desserts/Desserts";
import MoneyBack from "../MoneyBack/MoneyBack";
import Recommendation from "../Recommendation/Recommendation";
import Sale from "../Sale/Sale";
import "./Home.css";

function Home(): JSX.Element {
  return (
    <div className="Home">
      {/* Events */}
      <Recommendation />

      {/* Display Lists */}
      <Desserts />

      {/* Props */}
      <Sale category="Beverages" percent={3} />
      <Sale category="Candies" percent={5} comments="only today" />

      {/* state */}
      <BestSeller />

      {/* useEffect */}
      <MoneyBack />

      <Clock />
    </div>
  );
}

export default Home;
