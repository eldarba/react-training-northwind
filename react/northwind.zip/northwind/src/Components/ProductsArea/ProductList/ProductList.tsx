import "./ProductList.css";

function ProductList(): JSX.Element {
    return (
        <div className="ProductList">
			product list...
        </div>
    );
}

export default ProductList;
