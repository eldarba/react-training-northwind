import "./About.css";

function About(): JSX.Element {
    return (
        <div className="About">
			about...
        </div>
    );
}

export default About;
