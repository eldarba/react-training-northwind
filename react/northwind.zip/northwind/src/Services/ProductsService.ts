import axios from "axios";
import ProductModel from "../Models/ProductModel";
import appConfig from "../Utils/Config";

class ProductsService {
  public getAllProducts() {
    const response = axios.get<ProductModel[]>(appConfig.productsUrl);
  }
}

const productService = new ProductsService();

export default productService;

